SMS API AND CAS API of BDAPPS are used here to deduct an Amount From the User.
To get it started You will need a Tap-simulator Provided by BDAPPS to simulate the scenario and also Xampp. 

An android app which triggers this code via sending an Sms  ( https://github.com/imranctg16/Demo_sms )

** Developer should Have Bdapps developer account to simulate this.
