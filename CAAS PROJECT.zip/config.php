<?php

define('hostname', 'localhost');
define('username', 'root');
define('password', '');
define('db_name', 'nrick');


?>